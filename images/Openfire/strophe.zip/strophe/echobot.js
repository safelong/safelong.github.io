//var BOSH_SERVICE = 'http://ldns-dt-1003:7070/http-bind/'
var BOSH_SERVICE = 'http://win8vm:7070/http-bind/'
var connection = null;

function log(msg) 
{
    $('#log').append('<div></div>').append(document.createTextNode(msg));
}

function loglink(url,name) 
{
	var link = "<a href='" + url +"'>" + name + "</a>";
    $('#log').append('<div></div>').append(link);
}

function onConnect(status)
{
    if (status == Strophe.Status.CONNECTING) {
	log('Strophe is connecting.');
    } else if (status == Strophe.Status.CONNFAIL) {
	log('Strophe failed to connect.');
	$('#connect').get(0).value = 'connect';
    } else if (status == Strophe.Status.DISCONNECTING) {
	log('Strophe is disconnecting.');
    } else if (status == Strophe.Status.DISCONNECTED) {
	log('Strophe is disconnected.');
	$('#connect').get(0).value = 'connect';
    } else if (status == Strophe.Status.CONNECTED) {
	log('Strophe is connected.');
	log('ECHOBOT: Send a message to ' + connection.jid + 
	    ' to talk to me.');

		
		//console.log(1);
	connection.addHandler(onMessage, null, 'message', null, null,  null); 
	
	
	//console.log(2);
	//console.log(3);
	
	var iq = $iq({type: 'get'}).c('query', {xmlns: 'jabber:iq:roster'});
	//console.log(iq);
	//console.log(4);

	connection.sendIQ(iq, on_roster);
//	setTimeout(function(){connection.send($pres());},2000);
//	setTimeout(function(){connection.send($pres());},2000);

	
	//	connection.addHandler(on_roster_changed, "jabber:iq:roster", "iq", "set");
//console.log(5);

//	connection.send($pres().tree());
	
//		var status = $pres({to: "ldns-dt-1003"}).c("show").t("away"); 
  //      connection.send(status); 
		
    }
}

function on_roster_changed(presence){
console.log('-------on_roster_changed');
console.log(presence);

/*
 var presence_type = $(presence).attr('type'); // unavailable, subscribed, etc...
  var from = $(presence).attr('from'); // the jabber_id of the contact
  if (presence_type != 'error'){
    if (presence_type === 'unavailable'){
      // Mark contact as offline
	  console.log(3);
    }else{
	console.log(6);
      var show = $(presence).find("show").text(); // this is what gives away, dnd, etc.
      if (show === 'chat' || show === ''){
        console.log(4);
      }else{
        console.log(5);
      }
    }
  }
  */
  
  return true;
}

function on_roster(r) {
	console.log('-----on_roster');
	console.log(r);
//	$(r).find('item').each(function (t1,t2) {
//		console.log('-----on_roster');
//		console.log(t2);
//	});
	
	//var elems = r.getElementsByTagName('item');
	//var jid = elems[0].getAttribute("jid");
	//console.log(jid);
	
		//var reply = $msg({to: 'test2@ldns-dt-1003', from: 'test1@ldns-dt-1003', type: 'chat'});
		//console.log(reply);
          //  reply = reply.cnode(Strophe.xmlElement('body', '' ,'12345'));
		//	console.log(reply);
	//connection.send(reply.tree());
	
	connection.addHandler(on_roster_changed, null, "presence");
	//connection.addHandler(on_roster_changed, "jabber:iq:roster", "iq", "set");
	//connection.send(null);
	connection.send($pres());
}

function onMessage(msg) {
	console.log(msg);
    var to = msg.getAttribute('to');
    var from = msg.getAttribute('from');
    var type = msg.getAttribute('type');
    var elems = msg.getElementsByTagName('body');
	var filetrans = msg.getElementsByTagName('filetransfer');
	
    if (type == "chat" && elems.length > 0) {
	
		var body = elems[0];
		
		if(filetrans.length > 0){
			loglink(Strophe.getText(body), 'ECHOBOT: I got a file from ' + from + ': ' + Strophe.getText(filetrans[0]));
		}
		else{
			log('ECHOBOT: I got a message from ' + from + ': ' + 
				Strophe.getText(body));
			
	//		var reply = $msg({to: from, from: to, type: 'chat'})
	//				.cnode(Strophe.copyElement(body));
	//		connection.send(reply.tree());

	//		log('ECHOBOT: I sent ' + from + ': ' + Strophe.getText(body));
		}
    }

    // we must return true to keep the handler alive.  
    // returning false would remove it after it finishes.
    return true;
}

$(document).ready(function () {
    connection = new Strophe.Connection(BOSH_SERVICE);

    // Uncomment the following lines to spy on the wire traffic.
//    connection.rawInput = function (data) { log('RECV: ' + data); };
//    connection.rawOutput = function (data) { log('SEND: ' + data); };

    // Uncomment the following line to see all the debug output.
//    Strophe.log = function (level, msg) { log('LOG: ' + msg); };


    $('#connect').bind('click', function () {
		var button = $('#connect').get(0);
		if (button.value == 'connect') {
			button.value = 'disconnect';

			//console.log($('#jid').get(0).value);
			//console.log($('#pass').get(0).value);
			connection.connect($('#jid').get(0).value,
					   $('#pass').get(0).value,
					   onConnect);
		} else {
			button.value = 'connect';
			connection.disconnect();
		}
    });
	
	$('#send').bind('click', function () {
		var reply = $msg({
							to: $('#sendto').get(0).value, 
							from: $('#jid').get(0).value, 
							type: 'chat'})
				.cnode(Strophe.xmlElement('body', '' ,$('#msg').get(0).value));

		connection.send(reply.tree());
		
		log('ECHOBOT: I send a message to ' + $('#sendto').get(0).value + ': ' + 
				$('#msg').get(0).value);
		
		//var iq = $iq({type: 'get', from:'testa@win8vm', to:'testb@win8vm', id:'hello'}).c('query', {xmlns: 'http://jabber.org/protocol/disco#info'});
		//connection.sendIQ(iq, ontest);
		
		//connection.si_filetransfer.send('testa@win8vm', connection._proto.sid, '1.txt', 100, 'text/plain', ontest);
		//connection.ibb.open('testa@win8vm', connection._proto.sid,  1024,  ontest);
		
		//var iq = $iq({type: 'get'}).c('sharedgroup', {xmlns: 'http://www.jivesoftware.org/protocol/sharedgroup'});
		//connection.sendIQ(iq, ontest);
		
		

		
	});

	$('#sendfile').bind('click', function () {
		$("#loading")
		.ajaxStart(function(){
			$(this).show();
		})
		.ajaxComplete(function(){
			$(this).hide();
		});

		var fn = $('#filename').val().split('/').pop().split('\\').pop();
		$.ajaxFileUpload
		(
			{
				url:'upload.html',
				secureuri:false,
				fileElementId:'filename',
				dataType: 'json',
				data:{name:fn},
				success: function (data, status)
				{
					console.log(data);
					
					var msg = $msg({
										to: $('#sendto').get(0).value, 
										from: $('#jid').get(0).value, 
										type: 'chat'})
							.cnode(Strophe.xmlElement('body', '' ,data.url))
							.up()
							.cnode(Strophe.xmlElement('filetransfer', '' ,fn));

					connection.send(msg.tree());
					
					log('ECHOBOT: I send a file to ' + $('#sendto').get(0).value + ': ' + 
						fn);
				},
				error: function (data, status, e)
				{
					console.log(e);
				}
			}
		);
		
		return false;
	});
	
	
	function ontest(m){
		console.log(m);
	}
	
});

