var domain="win8vm";
var subdomain="broadcastextend";
var BOSH_SERVICE = 'http://win8vm:7070/http-bind/';
var connection = null;
var isVerbose = true;
var isAttach = false;
var rosters = [];
var groups = [];

function clog(c){
	console.log(c);
}

function saveRosterStatus(roster, isOnline){
	if(isOnline){ $.cookie(roster,"1"); }
	else { $.removeCookie(roster); }
}

function saveJid(jid){
	$.cookie("jid",jid);
}

function saveSid(sid){
	$.cookie("sid",sid);
}

function saveRid(rid){
	$.cookie("rid",rid);
}

function addDomain(jid){
	if(jid.indexOf('@') >=0){
		return jid;
	}
	return jid+"@"+domain;
}

function addGroupDomain(jid){
	if(jid.indexOf('@') >=0){
		return jid;
	}
	return jid+"@"+subdomain+"."+domain;
}

function removeDomain(jid){
	return jid.split('@')[0];
}

function receiveMessageLog(from, msg, groupname){
	var content = 'got message from ' + from + ':' + msg;
	if(groupname !== ''){
		content += '('+groupname+')';
	}
    $('#message').append('<div class="receive">'+content+'</div>');
}

function receiveFileLog(from, fileurl, filename, groupname){
	var content = 'got file from ' + from + ':' + "<a href='" + fileurl +"'>" + filename + "</a>";
	if(groupname !== ''){
		content += '('+groupname+')';
	}
    $('#message').append('<div class="receive">'+content+'</div>');
}

function sendMessageLog(to, msg){
	var content = 'send message to ' + to + ':' + msg;
    $('#message').append('<div>'+content+'</div>');
}

function sendFileLog(to, fileurl, filename){
	var content = 'send file to ' + to + ':' + "<a href='" + fileurl +"'>" + filename + "</a>";
    $('#message').append('<div>'+content+'</div>');
}

function displayContact(){
	var c = "";
	rosters.forEach(function(e){
		var id = removeDomain(e.jid);

		var online = "";
		if(isAttach && $.cookie(id) === "1"){
			online = 'online';
		}
		
		c += '<div id="roster_'+id+'" class="roster '+online+'">'+e.name+'</div>';
	});
	groups.forEach(function(e){
		c += '<div class="group">'+e+'</div>';
	});
	
	$('#contact').append(c);
}

function log(info){
	$('#log').prepend($('<div></div>').append(document.createTextNode(info)));
}

function onConnect(status){
    if (status == Strophe.Status.CONNECTING) {
		$('#log').text('');
		log('Strophe is connecting.');
    } else if (status == Strophe.Status.ERROR) {
		log('Strophe error to connect.');
		if($('#connect').length){
			$('#connect').get(0).value = 'connect';
		}
    } else if (status == Strophe.Status.CONNFAIL) {
		log('Strophe failed to connect.');
		if($('#connect').length){
			$('#connect').get(0).value = 'connect';
		}
	} else if (status == Strophe.Status.DISCONNECTING) {
		log('Strophe is disconnecting.');
    } else if (status == Strophe.Status.DISCONNECTED) {
		log('Strophe is disconnected.');
		$('#connect').get(0).value = 'connect';
		$('#message').text('');
		$('#contact').text('');
    } else if (status == Strophe.Status.ATTACHED) {
		log('Strophe is attached.');
		rosters = [];
		groups = [];
		isAttach = true;
		connection.addHandler(onMessage, null, 'message', null, null,  null); 
		var iq = $iq({type: 'get'}).c('query', {xmlns: 'jabber:iq:roster'});
		connection.sendIQ(iq, on_roster);
		//saveRid(connection._proto.rid);
    } else if (status == Strophe.Status.CONNECTED) {
		log('Strophe is connected.');
		rosters = [];
		groups = [];
		//saveJid(connection.jid);
		//saveSid(connection._proto.sid);
		connection.addHandler(onMessage, null, 'message', null, null,  null); 
		var iq = $iq({type: 'get'}).c('query', {xmlns: 'jabber:iq:roster'});
		connection.sendIQ(iq, on_roster);
		//saveRid(connection._proto.rid);
    }
}

function onMessage(msg) {
    var to = msg.getAttribute('to');
    var from = msg.getAttribute('from');
    var type = msg.getAttribute('type');
    var body = msg.getElementsByTagName('body');
	var filetrans = msg.getElementsByTagName('filetransfer');
	var groupinfo = msg.getElementsByTagName('groupinfo');
	
    if (type == "chat" && body.length > 0) {
		var groupname = '';
		if(groupinfo.length > 0){
			groupname = Strophe.getText(groupinfo[0]);
		}
		
		if(filetrans.length > 0){
			receiveFileLog(removeDomain(from) ,Strophe.getText(body[0]), Strophe.getText(filetrans[0]), groupname);
		}
		else{
			receiveMessageLog(removeDomain(from), Strophe.getText(body[0]), groupname);
		}
    }

    // we must return true to keep the handler alive.  
    // returning false would remove it after it finishes.
    return true;
}

function on_roster(r) {
	clog('on_roster');
	$(r).find('item').each(function () {
		var i = removeDomain($(this).attr('jid'));
		var n = $(this).attr('name');
		rosters.push({jid:i,name:n});
		$(this).find('group').each(function () {
			var v = $(this).text();
			if($.inArray(v, groups) == -1){
				groups.push(v);
			}
		});
	});

	displayContact();
	
	connection.addHandler(on_roster_changed, null, "presence");
	connection.send($pres());
	//saveRid(connection._proto.rid);
}

function on_roster_changed(presence){
	clog('on_roster_changed');
	var presence_type = $(presence).attr('type'); // unavailable, subscribed, etc...
	var from = removeDomain($(presence).attr('from')); // the jabber_id of the contact
	var self = removeDomain(connection.jid);

	if (from != self && presence_type != 'error'){
		if(presence_type === 'unavailable'){
			// Mark contact as offline
			$("#roster_"+from).removeClass('online');
			saveRosterStatus(from,false);
		}
		else if(!presence_type){
			// Mark contact as online
			$("#roster_"+from).addClass('online');
			saveRosterStatus(from,true);
		}
	}
	
	return true;
}

function doConnect(){
	var button = $('#connect');
	if (button.val() == 'connect') {
		button.val('disconnect');
		connection.connect(addDomain($('#jid').val()),$('#pass').val(),onConnect);
	} else {
		button.val('connect');
		connection.disconnect();
	}
}

function sendMessage(e){
	var tojid = "";
	if(e.target.id === "sendg"){
		tojid = addGroupDomain($('#sendto').val());
	}
	else{
		tojid = addDomain($('#sendto').val());
	}
	
	var reply = $msg({  to: tojid, 
						from: connection.jid, 
						type: 'chat'})
				.cnode(Strophe.xmlElement('body', '' ,$('#msg').val()));
	connection.send(reply.tree());
	//saveRid(connection._proto.rid);
	sendMessageLog(removeDomain(tojid), $('#msg').val());
}

function sendFile(e){
	var tojid = "";
	if(e.target.id === "sendfileg"){
		tojid = addGroupDomain($('#sendfileto').val());
	}
	else{
		tojid = addDomain($('#sendfileto').val());
	}

	$("#loading").ajaxStart(function(){
		$(this).show();
	}).ajaxComplete(function(){
		$(this).hide();
	});

	var fn = $('#filename').val().split('/').pop().split('\\').pop();
	$.ajaxFileUpload
	(
		{
			url:'upload.html',
			secureuri:false,
			fileElementId:'filename',
			dataType: 'json',
			data:{name:fn},
			success: function (data, status)
			{
				var msg = $msg({	to: tojid, 
									from: connection.jid, 
									type: 'chat'})
						.cnode(Strophe.xmlElement('body', '' ,data.url))
						.up()
						.cnode(Strophe.xmlElement('filetransfer', '' ,fn));
				connection.send(msg.tree());
				//saveRid(connection._proto.rid);
				
				sendFileLog(removeDomain(tojid), data.url, fn);
			},
			error: function (data, status, e)
			{
				log('error:'+e);
			}
		}
	);
	
	return false;
}

$(document).ready(function () {
    connection = new Strophe.Connection(BOSH_SERVICE);

	connection.rawOutput = function () { 
		clog('save:' + connection.jid + ',' + connection._proto.sid + ',' + (connection._proto.rid-1));
		saveJid(connection.jid);
		saveSid(connection._proto.sid);
		saveRid(connection._proto.rid-1);
	};
	
	if(isVerbose){
		var f = connection.rawOutput;
		connection.rawInput = function (data) { log('********RECV: ' + data); };
		connection.rawOutput = function (data) { f(data); log('********SEND: ' + data); };
		Strophe.log = function (level, msg) { log('********LOG : ' + msg); };
	}

	if($('#connect').length){
		$('#connect').bind('click', doConnect);
	}
	else{
		var jid = $.cookie("jid");
		var sid = $.cookie("sid");
		var rid = $.cookie("rid");
		clog('attach connect:' + jid + ',' + sid + ',' + rid);
		connection.attach(jid,sid,rid,onConnect);
	}
	
	$('#disconnect').bind('click', function(){connection.disconnect();});
	
	$('#send').bind('click',sendMessage);
	$('#sendg').bind('click',sendMessage);
	$('#sendfile').bind('click', sendFile);
	$('#sendfileg').bind('click', sendFile);
});

