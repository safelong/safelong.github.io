// if connect to openfire connection manager, MUST use this plugin
// if data is restart, then send bind request together.

// a way
Strophe.Bosh.prototype._onIdleCm = function () {
	var data = this._conn._data;

	// if no requests are in progress, poll
	if (this._conn.authenticated && this._requests.length === 0 &&
		data.length === 0 && !this._conn.disconnecting) {
		Strophe.info("no requests during idle cycle, sending " +
					 "blank request");
		data.push(null);
	}

	if (this._requests.length < 2 && data.length > 0 &&
		!this._conn.paused) {
		var body = this._buildBody();
		for (var i = 0; i < data.length; i++) {
			if (data[i] !== null) {
				if (data[i] === "restart") {
					body.attrs({
						to: this._conn.domain,
						"xml:lang": "en",
						"xmpp:restart": "true",
						"xmlns:xmpp": Strophe.NS.BOSH
					});
					
					//added by yangyc
					//send bind request 
					this._conn.do_session = true; // important!!!
					this._conn._addSysHandler(this._conn._sasl_bind_cb.bind(this._conn), null, null,
							null, "_bind_auth_2");
					body.cnode(
						$iq({type: "set", id: "_bind_auth_2",xmlns: Strophe.NS.CLIENT})
							.c('bind', {xmlns: Strophe.NS.BIND})
							.c('resource', {xmlns: Strophe.NS.BIND}).t(this.sid).tree()
					).up();
					//added end
				} else {
					body.cnode(data[i]).up();
				}
			}
		}
		delete this._conn._data;
		this._conn._data = [];
		this._requests.push(
			new Strophe.Request(body.tree(),
								this._onRequestStateChange.bind(
									this, this._conn._dataRecv.bind(this._conn)),
								body.tree().getAttribute("rid")));
		this._processRequest(this._requests.length - 1);
	}

	if (this._requests.length > 0) {
		var time_elapsed = this._requests[0].age();
		if (this._requests[0].dead !== null) {
			if (this._requests[0].timeDead() >
				Math.floor(Strophe.SECONDARY_TIMEOUT * this.wait)) {
				this._throttledRequestHandler();
			}
		}

		if (time_elapsed > Math.floor(Strophe.TIMEOUT * this.wait)) {
			Strophe.warn("Request " +
						 this._requests[0].id +
						 " timed out, over " + Math.floor(Strophe.TIMEOUT * this.wait) +
						 " seconds since last activity");
			this._throttledRequestHandler();
		}
	}
};

//////////////////////////////////////////////////////////////////////////////////////////

// another way
Strophe.Bosh.prototype._sendRestartCm = function () {
	// addded by yangyc
	this._conn.do_session = true; // important!!!
	this._conn._addSysHandler(this._conn._sasl_bind_cb.bind(this._conn), null, null,
			null, "_bind_auth_2");
	var $bindData = $iq({type: "set", id: "_bind_auth_2",xmlns: Strophe.NS.CLIENT})
					 .c('bind', {xmlns: Strophe.NS.BIND})
					 .c('resource', {xmlns: Strophe.NS.BIND}).t(this.sid).tree();
	this._conn._data.push($bindData);
	// added end
	this._throttledRequestHandler();
	clearTimeout(this._conn._idleTimeout);
};

