
var ChatClient = (function(){
	var Util = {
		
		log : function (info){
			console.log(info);
		},
		
		getGroupId : function (g){
			return (new RegExp("^(.*)\{(.*)}$","ig")).exec(g)[2];
		},

		getGroupName : function (g){
			return (new RegExp("^(.*)\{(.*)}$","ig")).exec(g)[1];
		}
	};

	var Controler = {

		getAllRosters : function(){
			Connection.connection.addHandler(this.onMessage, null, 'message', null, null,  null); 
			var iq = $iq({type: 'get'}).c('query', {xmlns: 'jabber:iq:roster'});
			setTimeout(function(){Connection.connection.sendIQ(iq, Controler.onRoster);}, 1000);
		},

		onRoster : function (r) {
			Util.log('onRoster');

			var rosters = [];
			var groups = [];

			$(r).find('item').each(function () {
				var i = Connection.getSimpleJid($(this).attr('jid'));
				var n = $(this).attr('name');
				rosters.push({jid:i,name:n});
				$(this).find('group').each(function () {
					var v = $(this).text();
					if($.inArray(v, groups) == -1){
						groups.push(v);
					}
				});
			});

			View.displayContact(rosters, groups);
			
			Connection.connection.addHandler(Controler.onRosterChanged, null, "presence");
			Connection.connection.send($pres());
		},

		onRosterChanged : function (presence){
			Util.log('onRosterChanged');
			
			// unavailable, subscribed, etc...
			var presence_type = $(presence).attr('type'); 
			// the jabber_id of the contact
			var from = Connection.getSimpleJid($(presence).attr('from')); 

			if (!Connection.isSelf(from) && presence_type != 'error'){
				if(presence_type === 'unavailable'){
					View.changeRosterStatusToOffline(from);
				}
				else if(!presence_type){
					View.changeRosterStatusToOnline(from);
				}
				
				View.changeChatWindowStatus(from);
			}
			
			return true;
		},

		onMessage : function (msg) {
			Util.log('onMessage');
			
			var to = msg.getAttribute('to');
			var from = msg.getAttribute('from');
			var type = msg.getAttribute('type');
			var body = msg.getElementsByTagName('body');
			var filetrans = msg.getElementsByTagName('filetransfer');
			var groupinfo = msg.getElementsByTagName('groupinfo');
			
			if (!Connection.isSelf(from) && type == "chat" && body.length > 0) {
				var group = '';
				if(groupinfo.length > 0){
					group = Strophe.getText(groupinfo[0]);
				}
				if(filetrans.length > 0){
					View.onReceiveFile(
						Connection.getSimpleJid(from),
						Strophe.getText(body[0]), 
						Strophe.getText(filetrans[0]), 
						group
					);
				}
				else{
					View.onReceiveMessage(
						Connection.getSimpleJid(from), 
						Strophe.getText(body[0]), 
						group
					);
				}
			}

			// we must return true to keep the handler alive.  
			// returning false would remove it after it finishes.
			return true;
		},
		
		sendMessage : function ($text){
			var tojid = "";
			if(View.isGroupChat($text)){
				tojid = Connection.getFullGroupJid(View.getTargetJId($text));
			}
			else{
				tojid = Connection.getFullJid(View.getTargetJId($text));
			}
			
			var reply = $msg({  to: tojid, 
								from: Connection.connection.jid, 
								type: 'chat'})
						.cnode(Strophe.xmlElement('body', '' ,$text.val()));
			Connection.connection.send(reply.tree());
			View.displayMessage($text, Connection.getSelfName()+":"+$text.val());
		},

		sendFile : function ($fileid){
			var tojid = "";
			if(View.isGroupChat($fileid)){
				tojid = Connection.getFullGroupJid(View.getTargetJId($fileid));
			}
			else{
				tojid = Connection.getFullJid(View.getTargetJId($fileid));
			}

			$fileid.ajaxStart(function(){
				View.showFileUploadingIcon($fileid);
				
			}).ajaxComplete(function(){
				View.showFileSelectIcon($fileid);
			});

			var fn = $fileid.val().split('/').pop().split('\\').pop();
			$.ajaxFileUpload
			(
				{
					url:Connection.options.fileUploadUrl,
					secureuri:false,
					fileElementId: $fileid[0].id,
					dataType: 'json',
					data:{name:fn},
					success: function (data, status)
					{
						var msg = $msg({	to: tojid, 
											from: Connection.connection.jid, 
											type: 'chat'})
								.cnode(Strophe.xmlElement('body', '' ,data.url))
								.up()
								.cnode(Strophe.xmlElement('filetransfer', '' ,fn));
						Connection.connection.send(msg.tree());
						
						View.displayMessage($fileid, Connection.getSelfName()+":"+fn);
					},
					error: function (data, status, e)
					{
						Util.log('error:'+e);
					}
				}
			);
			
			return false;
		}
	};
	
	var View = {
		
		showFileUploadingIcon : function($target){
			var jid = $target.attr('name').substr('file_upload_'.length);
			var $img = $("#chat_window_"+jid).find('.chat-window-file-select');
			$img.addClass('loading');
		},
	
		showFileSelectIcon : function($target){
			var jid = $target.attr('name').substr('file_upload_'.length);
			var $img = $("#chat_window_"+jid).find('.chat-window-file-select');
			$img.removeClass('loading');
		},

		displayMessage : function ($e, text){
			var $target;
			if($e.hasClass("chat-window-inner-content")){
				$target = $e;
			}
			else{
				$target = $e.parent().prev();
			}
			
			var $messageP = $("<p/>").append(text);
			$messageP.appendTo($target.find('.chat-message'));
			$target.scrollTop($target[0].scrollHeight);
		},
		
		isGroupChat : function ($text){
			return $text.parents('.chat-window').find(".chat-window-title").hasClass('group');
		},

		getTargetJId : function ($text){
			return $text.parents('.chat-window')[0].id.substr('chat_window_'.length);
		},

		changeChatWindowStatus : function (id){
			var status = $("#"+id).find(".profile-status").attr('class').split(' ')[1];
			$('#chat_window_'+id).find(".chat-window-title").attr('class','chat-window-title '+status);
		},

		changeRosterStatusToOffline : function(from){
			$("#"+from+" > .profile-status").removeClass('online').addClass('offline');
		},
		
		changeRosterStatusToOnline : function(from){
			$("#"+from+" > .profile-status").removeClass('offline').addClass('online');
		},

		createChatWindow : function (id){
			$template = $('.chat-window-template > div').clone(true);
			$('body').append($template);
			$template.attr('id','chat_window_'+id);
			$template.find(".chat-window-caption").text($('#'+id).find('.content').text());
			$template.find(".chat-window-file").attr('id','file_upload_'+id);
			$template.find(".chat-window-file").attr('name','file_upload_'+id);
		},

		activeChatWindow : function (id){
			if($('#chat_window_'+id).length){
			}
			else{
				this.createChatWindow(id);
			}

			$('#chat_window_'+id).show();
			$('#chat_window_'+id).find(".chat-window-content").show();
			this.changeChatWindowStatus(id);
			
			return $('#chat_window_'+id);
		},

		displayContact : function (rosters, groups){
			var c = "";

			rosters.forEach(function(e){
				var id = Connection.getSimpleJid(e.jid);

				var status = "offline";
				
				c += '<div class="user-list-item" id="'+id+'">'+
						'<div class="profile-status '+status+'"></div>'+
						'<div class="content">'+e.name+'</div>'+
					 '</div>';
			});
			groups.forEach(function(g){
				c += '<div class="user-list-item" id="'+Util.getGroupId(g)+'">'+
						'<div class="profile-status group"></div>'+
						'<div class="content">'+Util.getGroupName(g)+'</div>'+
					 '</div>';
			});
			
			$('.roster_list_window .chat-window-inner-content').append(c);
		},

		onReceiveMessage : function (from, msg, groupid){
			var $w = this.activeChatWindow(groupid || from);
			this.displayMessage($w.find(".chat-window-inner-content"), from + ':' + msg);
		},

		onReceiveFile : function (from, fileurl, filename, groupid){
			var $w = this.activeChatWindow(groupid || from);
			this.displayMessage($w.find(".chat-window-inner-content"), from + ':' + "<a href='" + fileurl +"'>" + filename + "</a>");
		},

		prepareView : function(){
			
			$(".chat-window-title").bind('click', function (e) {
				$(this).next().toggle();
				e.preventDefault();
			});

			$(".chat-window-inner-content").on('click', ".user-list-item", function () {
				View.activeChatWindow(this.id);
			});
			
			$(".chat-window-file-select").on('click', function () {
				$(this).next().click();
			});
			
			$(".chat-window-text-box-wrapper").on('change', '.chat-window-file',function(){
				Controler.sendFile($(this));
			});
			
			$(".chat-window-close").bind('click', function () {
				$(this).closest('.chat-window').hide();
			});
			
			$(".chat-window-text-box").bind('keypress', function (e) {
				if (e.which == 13) {
					e.preventDefault();
					if ($(this).val()) {
						Controler.sendMessage($(this));
						$(this).val('');
					}
				}
			});
		}
	};
	
	var Connection = {
		subdomain : "broadcastextend",
		
		saveConnectionInfo : function() {
			var jid = this.getSimpleJid(this.connection.jid);
			var sid = this.connection._proto.sid;
			var rid = this.connection._proto.rid-1;
			
			Util.log('save:' + jid + ',' + sid + ',' + rid);
			$.cookie("jid",jid);
			$.cookie("sid",sid);
			$.cookie("rid",rid);
		},

		getSimpleJid : function (jid){
			return jid.split('@')[0];
		},

		getFullJid : function (jid){
			if(jid.indexOf('@') >=0){
				return jid;
			}
			return jid+"@"+this.domain;
		},

		getFullGroupJid : function (jid){
			if(jid.indexOf('@') >=0){
				return jid;
			}
			return jid+"@"+this.subdomain+"."+this.domain;
		},

		getSelfName : function (){
			return this.getSimpleJid(this.connection.jid);
		},
		
		isSelf : function(jid){
			return this.getSimpleJid(jid) == this.getSimpleJid(this.connection.jid);
		},

		init : function(service, domain, options){
			this.domain = domain;
			this.connection = new Strophe.Connection(service /*, {sync: true} */);
			this.options = {isDebugMode: false, isConnectOnly: false};
			$.extend(this.options, options);

			this.connection.rawOutput = function () { 
				Connection.saveConnectionInfo();
			};
			
			if(this.options.isDebugMode){
				var f = this.connection.rawOutput;
				this.connection.rawInput = function (data) { Util.log('RECV: ' + data); };
				this.connection.rawOutput = function (data) { f(data); Util.log('SEND: ' + data); };
				Strophe.log = function (level, msg) { Util.log('log : ' + msg); };
			}
			
			if(!this.options.isConnectOnly){
				View.prepareView();
			}
		},
		
		onConnectDefault : function (status){
			if (status == Strophe.Status.CONNECTING) {
				Util.log('Strophe is connecting.');
			} else if (status == Strophe.Status.ERROR) {
				Util.log('Strophe error to connect.');
			} else if (status == Strophe.Status.CONNFAIL) {
				Util.log('Strophe failed to connect.');
			} else if (status == Strophe.Status.DISCONNECTING) {
				Util.log('Strophe is disconnecting.');
			} else if (status == Strophe.Status.DISCONNECTED) {
				Util.log('Strophe is disconnected.');
			} else if (status == Strophe.Status.ATTACHED) {
				Util.log('Strophe is attached.');
				if(!this.options.isConnectOnly){
					Controler.getAllRosters();
				}
			} else if (status == Strophe.Status.CONNECTED) {
				Util.log('Strophe is connected.');
				if(!this.options.isConnectOnly){
					Controler.getAllRosters();
				}
			}
		},
		
		connect : function(jid, pass, onSuccess, onFail){
			this.connection.connect(this.getFullJid(jid), pass, function(status){
				Connection.onConnectDefault(status);

				if (status == Strophe.Status.CONNECTED){
					//connection.send($pres()); //not necessary
					setTimeout(onSuccess,500);
				}			
				else if (status == Strophe.Status.CONNFAIL || 
						 status == Strophe.Status.ERROR){
					setTimeout(onFail,500);
				}
			});
		},

		attach : function(onSuccess, onFail){
			var jid = $.cookie("jid");
			var sid = $.cookie("sid");
			var rid = $.cookie("rid");
			
			Util.log('attach connect:' + jid + ',' + sid + ',' + rid);

			this.connection.attach(this.getFullJid(jid),sid,rid,function(status){
				Connection.onConnectDefault(status);

				if (status == Strophe.Status.ATTACHED){
					//connection.send($pres()); //not necessary
					setTimeout(onSuccess,500);
				}			
				else if (status == Strophe.Status.CONNFAIL || 
						 status == Strophe.Status.ERROR){
					setTimeout(onFail,500);
				}
			});
		},		

		disconnect : function(callback) {
			this.connection.disconnect();
			setTimeout(callback, 1000);
		}
	};
	
	return {
		init : function(service, domain, options){
			Connection.init(service, domain, options);
		},
	
		connect : function(jid, pass, onSuccess, onFail){
			Connection.connect(jid, pass, onSuccess, onFail);
		},
		
		attach : function(onSuccess, onFail){
			Connection.attach(onSuccess, onFail);
		},
		
		disconnect : function(callback) {
			Connection.disconnect(callback);
		}	
	};
})();
