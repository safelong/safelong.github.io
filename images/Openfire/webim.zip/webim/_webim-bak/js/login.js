
$(document).ready(function () {
	$("#connect").click(function(){
		var jid = addDomain($('#name').val());
		var pass = $('#pass').val();
		
		connection.connect(jid, pass, function(status){
			onConnect(status);

			if (status == Strophe.Status.CONNECTED) {
				//connection.send($pres()); //not necessary
				setTimeout(function(){form1.submit();},500);
			}			
		});
	});
});

