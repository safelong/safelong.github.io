var domain="win8vm";
var subdomain="broadcastextend";
var BOSH_SERVICE = 'http://win8vm:7070/http-bind/';
var connection = null;

/*
function saveRosterStatus(roster, isOnline){
	if(isOnline){ $.cookie(roster,"1"); }
	else { $.removeCookie(roster); }
}
*/

function saveJid(jid){
	$.cookie("jid",jid);
}

function saveSid(sid){
	$.cookie("sid",sid);
}

function saveRid(rid){
	$.cookie("rid",rid);
}

function addDomain(jid){
	if(jid.indexOf('@') >=0){
		return jid;
	}
	return jid+"@"+domain;
}

function addGroupDomain(jid){
	if(jid.indexOf('@') >=0){
		return jid;
	}
	return jid+"@"+subdomain+"."+domain;
}

function removeDomain(jid){
	return jid.split('@')[0];
}

function getGroupId(g){
	return (new RegExp("^(.*)\{(.*)}$","ig")).exec(g)[2];
}

function getGroupName(g){
	return (new RegExp("^(.*)\{(.*)}$","ig")).exec(g)[1];
}

function getSelfName(){
	return removeDomain(connection.jid);
}

function log(info){
	$('#log').append($('<div></div>').append(document.createTextNode(info)));
}

function onConnect(status){
    if (status == Strophe.Status.CONNECTING) {
		log('Strophe is connecting.');
    } else if (status == Strophe.Status.ERROR) {
		log('Strophe error to connect.');
    } else if (status == Strophe.Status.CONNFAIL) {
		log('Strophe failed to connect.');
	} else if (status == Strophe.Status.DISCONNECTING) {
		log('Strophe is disconnecting.');
    } else if (status == Strophe.Status.DISCONNECTED) {
		log('Strophe is disconnected.');
    } else if (status == Strophe.Status.ATTACHED) {
		log('Strophe is attached.');
    } else if (status == Strophe.Status.CONNECTED) {
		log('Strophe is connected.');
    }
}

$(document).ready(function () {
    connection = new Strophe.Connection(BOSH_SERVICE /*, {sync: true} */);
	//connection.options.sync = true;

	connection.rawOutput = function () { 
		log('save:' + connection.jid + ',' + connection._proto.sid + ',' + (connection._proto.rid-1));
		saveJid(removeDomain(connection.jid));
		saveSid(connection._proto.sid);
		saveRid(connection._proto.rid-1);
	};
	
	var f = connection.rawOutput;
	connection.rawInput = function (data) { log('RECV: ' + data); };
	connection.rawOutput = function (data) { f(data); log('SEND: ' + data); };
	//Strophe.log = function (level, msg) { log('log : ' + msg); };
});

