var rosters = [];
var groups = [];


function displayContact(){
	var c = "";
	rosters.forEach(function(e){
		var id = removeDomain(e.jid);

		var status = "offline";
		//if($.cookie(id) === "1"){
		//	status = 'online';
		//}
		
		c += '<div class="user-list-item" id="'+id+'">'+
				'<div class="profile-status '+status+'"></div>'+
				'<div class="content">'+e.name+'</div>'+
			 '</div>';
	});
	groups.forEach(function(g){
		c += '<div class="user-list-item" id="'+getGroupId(g)+'">'+
				'<div class="profile-status group"></div>'+
				'<div class="content">'+getGroupName(g)+'</div>'+
			 '</div>';
	});
	
	$('#roster_list > div:first-child').append(c);
}


function onAttach(status){
	onConnect(status);

	if (status == Strophe.Status.ATTACHED) {
		rosters = [];
		groups = [];
		connection.addHandler(onMessage, null, 'message', null, null,  null); 
		var iq = $iq({type: 'get'}).c('query', {xmlns: 'jabber:iq:roster'});
		setTimeout(function(){connection.sendIQ(iq, onRoster);}, 1000);
    }
}


function onRoster(r) {
	log('onRoster');
	$(r).find('item').each(function () {
		var i = removeDomain($(this).attr('jid'));
		var n = $(this).attr('name');
		rosters.push({jid:i,name:n});
		$(this).find('group').each(function () {
			var v = $(this).text();
			if($.inArray(v, groups) == -1){
				groups.push(v);
			}
		});
	});

	displayContact();
	
	connection.addHandler(onRosterChanged, null, "presence");
	connection.send($pres());
}

function onRosterChanged(presence){
	log('onRosterChanged');
	var presence_type = $(presence).attr('type'); // unavailable, subscribed, etc...
	var from = removeDomain($(presence).attr('from')); // the jabber_id of the contact
	var self = removeDomain(connection.jid);

	if (from != self && presence_type != 'error'){
		if(presence_type === 'unavailable'){
			$("#"+from+" > .profile-status").removeClass('online').addClass('offline');
			//saveRosterStatus(from,false);
		}
		else if(!presence_type){
			$("#"+from+" > .profile-status").removeClass('offline').addClass('online');
			//saveRosterStatus(from,true);
		}
		
		changeChatWindowStatus(from);
	}
	
	return true;
}

function onMessage(msg) {
    var to = msg.getAttribute('to');
    var from = msg.getAttribute('from');
    var type = msg.getAttribute('type');
    var body = msg.getElementsByTagName('body');
	var filetrans = msg.getElementsByTagName('filetransfer');
	var groupinfo = msg.getElementsByTagName('groupinfo');
	
    if (removeDomain(from) != removeDomain(connection.jid) && type == "chat" && body.length > 0) {
		var group = '';
		if(groupinfo.length > 0){
			group = Strophe.getText(groupinfo[0]);
		}
		if(filetrans.length > 0){
			receiveFile(removeDomain(from) ,Strophe.getText(body[0]), Strophe.getText(filetrans[0]), group);
		}
		else{
			receiveMessage(removeDomain(from), Strophe.getText(body[0]), group);
		}
    }

    // we must return true to keep the handler alive.  
    // returning false would remove it after it finishes.
    return true;
}


function receiveMessage(from, msg, groupid){
	var $w = activeChatWindow(groupid || from);
	displayMessage($w.find(".chat-window-inner-content"), from + ':' + msg);
}

function receiveFile(from, fileurl, filename, groupid){
	var $w = activeChatWindow(groupid || from);
	displayMessage($w.find(".chat-window-inner-content"), from + ':' + "<a href='" + fileurl +"'>" + filename + "</a>");
}

function sendFile($fileid){
	var tojid = "";
	if(isGroupChat($fileid)){
		tojid = addGroupDomain(getTargetId($fileid));
	}
	else{
		tojid = addDomain(getTargetId($fileid));
	}

	$fileid.prev().ajaxStart(function(){
		$(this).attr('src','img/loading.gif');
	}).ajaxComplete(function(){
		$(this).attr('src','img/file.png');
	});

	var fn = $fileid.val().split('/').pop().split('\\').pop();
	$.ajaxFileUpload
	(
		{
			url:'upload.html',
			secureuri:false,
			fileElementId: $fileid[0].id,
			dataType: 'json',
			data:{name:fn},
			success: function (data, status)
			{
				var msg = $msg({	to: tojid, 
									from: connection.jid, 
									type: 'chat'})
						.cnode(Strophe.xmlElement('body', '' ,data.url))
						.up()
						.cnode(Strophe.xmlElement('filetransfer', '' ,fn));
				connection.send(msg.tree());
				
				displayMessage($fileid.parent().prev(), getSelfName()+":"+fn);
			},
			error: function (data, status, e)
			{
				log('error:'+e);
			}
		}
	);
	
	return false;
}

function displayMessage($target, text){
	var $messageP = $("<p/>").append(text);
	$messageP.appendTo($target.find('.chat-message'));
	$target.scrollTop($target[0].scrollHeight);
}

function isGroupChat($text){
	return $text.parents('.chat-window').find(".chat-window-title").hasClass('group');
}

function getTargetId($text){
	return $text.parents('.chat-window')[0].id.substr('chat_window_'.length);
}

function sendMessage($text){
	var tojid = "";
	if(isGroupChat($text)){
		tojid = addGroupDomain(getTargetId($text));
	}
	else{
		tojid = addDomain(getTargetId($text));
	}
	
	var reply = $msg({  to: tojid, 
						from: connection.jid, 
						type: 'chat'})
				.cnode(Strophe.xmlElement('body', '' ,$text.val()));
	connection.send(reply.tree());
	displayMessage($text.parent().prev(), getSelfName()+":"+$text.val());
}

function activeChatWindow(id){
	if($('#chat_window_'+id).length){
	}
	else{
		createChatWindow(id);
	}

	$('#chat_window_'+id).show();
	$('#chat_window_'+id).find(".chat-window-content").show();
	changeChatWindowStatus(id);
	
	return $('#chat_window_'+id);
}

function changeChatWindowStatus(id){
	var status = $("#"+id).find(".profile-status").attr('class').split(' ')[1];
	$('#chat_window_'+id).find(".chat-window-title").attr('class','chat-window-title '+status);
}

function createChatWindow(id){
	$template = $('#chat_window_template > div').clone(true);
	$('body').append($template);
	$template.attr('id','chat_window_'+id);
	$template.find(".text").text($('#'+id).find('.content').text());
	$template.find(".chat-window-file").attr('id','file_upload_'+id);
	$template.find(".chat-window-file").attr('name','file_upload_'+id);
}

function disconnect(){
	connection.disconnect();
	//window.location = "login.html";
	setTimeout(function(){window.location = "login.html";}, 1000);
}

$(document).ready(function () {
	var jid = $.cookie("jid");
	var sid = $.cookie("sid");
	var rid = $.cookie("rid");
	
	log('attach connect:' + jid + ',' + sid + ',' + rid);
	connection.attach(addDomain(jid),sid,rid,onAttach);
	
	$('#disconnect').bind('click', disconnect);

	$(".chat-window-title").bind('click', function (e) {
		$(this).next().toggle();
		e.preventDefault();
	});

	$(".chat-window-inner-content").on('click', ".user-list-item", function () {
		activeChatWindow(this.id);
	});
	
	$(".chat-window-file-select").on('click', function () {
		$(this).next().click();
	});
	
	$(".chat-window-file").on('change', function(){
		sendFile($(this));
	});
	
	$(".close").bind('click', function () {
		$(this).closest('.chat-window').hide();
	});
	
	$(".chat-window-text-box").bind('keypress', function (e) {
		if (e.which == 13) {
			e.preventDefault();
			if ($(this).val()) {
				sendMessage($(this));
				$(this).val('');
			}
		}
	});
});
