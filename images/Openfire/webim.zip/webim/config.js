
// c : centos
// w : win8vm
// m : centos connection manager
var flag = 'c';

var config = {isDebugMode : true};

if(flag === 'c'){
	config.domain = '127.0.0.1';
	config.service = 'http://192.168.116.152:7070/http-bind/';
	config.isUseCm = false;
}
else if(flag === 'w'){
	config.domain = 'win8vm';
	config.service = 'http://win8vm:7070/http-bind/';
	config.isUseCm = false;
}
else if(flag === 'm'){
	config.domain = '127.0.0.1';
	config.service = 'http://win8vm:7070/http-bind/';
	config.isUseCm = true;
}
